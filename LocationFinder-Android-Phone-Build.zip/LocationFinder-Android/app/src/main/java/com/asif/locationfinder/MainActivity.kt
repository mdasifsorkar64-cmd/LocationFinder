package com.asif.locationfinder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private val orange = Color.rgb(255, 105, 0)
    private lateinit var status: TextView
    private lateinit var consent: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); setBackgroundColor(Color.rgb(250,250,250)) }
        root.addView(TextView(this).apply { text = "📍 Location Finder"; textSize = 28f; setTextColor(orange); gravity = Gravity.CENTER })
        root.addView(TextView(this).apply { text = "Family Safety • Share only with permission"; textSize = 14f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(0,8,0,24) })
        status = TextView(this).apply { text = "আপনার লোকেশন এখনো শেয়ার করা হয়নি।"; textSize = 17f; setTextColor(Color.BLACK); setPadding(0,18,0,18) }
        root.addView(status)
        consent = CheckBox(this).apply { text = "আমি স্বেচ্ছায় আমার বর্তমান লোকেশন শেয়ার করতে সম্মত"; textSize = 15f }
        root.addView(consent)
        root.addView(Button(this).apply { text = "একবারের লোকেশন শেয়ার"; setOnClickListener { if (consent.isChecked) shareCurrentLocation() else status.text = "আগে সম্মতি দিন।" } })
        root.addView(Button(this).apply { text = "লাইভ লোকেশন শেয়ার (সেটআপ প্রয়োজন)"; setOnClickListener { status.text = "লাইভ পারিবারিক শেয়ারিং চালু করতে নিরাপদ সার্ভার, সদস্যদের অ্যাকাউন্ট ও প্রত্যেকের সম্মতি সেটআপ করতে হবে। এই ডেমোতে লাইভ ট্র্যাকিং সক্রিয় নয়।" } })
        root.addView(Button(this).apply { text = "সম্মতি বাতিল / শেয়ার বন্ধ"; setOnClickListener { consent.isChecked = false; status.text = "এই ডিভাইস থেকে শেয়ারের সম্মতি বন্ধ।" } })
        root.addView(TextView(this).apply { text = "\nগোপন ট্র্যাকিং নেই। প্রত্যেক সদস্য নিজের ফোনে অনুমতি দেবেন এবং যেকোনো সময় বন্ধ করতে পারবেন।\n\nনোট: এটি প্রাথমিক APK প্রজেক্ট। লাইভ পরিবারের লোকেশন, আমন্ত্রণ ও ম্যাপের জন্য Firebase/সার্ভার কনফিগারেশন এখনো যোগ করা হয়নি।"; textSize = 13f; setTextColor(Color.DKGRAY) })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun shareCurrentLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 101)
            status.text = "লোকেশন অনুমতি দিন, তারপর আবার চাপুন।"; return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null }
                if (l != null && (best == null || l.accuracy < best!!.accuracy)) best = l
            }
            if (best == null) { status.text = "লোকেশন পাওয়া যায়নি। GPS চালু করে আবার চেষ্টা করুন।"; return }
            val url = "https://maps.google.com/?q=${best.latitude},${best.longitude}"
            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "আমার বর্তমান লোকেশন: $url") }
            startActivity(Intent.createChooser(send, "লোকেশন শেয়ার করুন"))
            status.text = "লোকেশন শেয়ার করার জন্য অ্যাপ বেছে নিন।"
        } catch (e: Exception) { status.text = "লোকেশন নেওয়া যায়নি: ${e.message}" }
    }
}
